package com.coll.OnlineCollaborate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCollaborateApplicationTests {

	@Test
	void contextLoads() {
	}

}
